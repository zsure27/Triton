"""Executable demo entry points."""
