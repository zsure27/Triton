"""Low-bit quantization helpers."""
